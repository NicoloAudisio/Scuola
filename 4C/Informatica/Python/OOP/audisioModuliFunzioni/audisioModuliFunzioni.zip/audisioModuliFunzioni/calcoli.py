def calcoloMedia(calcoloM, n):
    calcoloM = calcoloM / n
    return calcoloM

def somma(totale, n):
    totale = totale + n
    return totale